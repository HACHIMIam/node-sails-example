module.exports.CONSTANTS = {
    SALT_ROUNDS: 5,
    EXPIRATION_DAYS_NUMBER: 10,
    TIME_UNITY: 'days',
    JWT_SECRET: 'kfnjekfnl',
  }